
MESSAGES={
  "welcome":{
    "en":"Welcome to EgyDiscovery! How can we help with your trip?",
    "ar":"مرحباً بك في إيجي ديسكفري! كيف نقدر نساعدك في رحلتك؟",
    "ru":"Добро пожаловать в EgyDiscovery! Чем мы можем помочь с поездкой?",
    "de":"Willkommen bei EgyDiscovery! Wobei können wir bei Ihrer Reise helfen?",
    "it":"Benvenuto su EgyDiscovery! Come possiamo aiutarti con il viaggio?",
    "fr":"Bienvenue chez EgyDiscovery ! Comment pouvons-nous vous aider pour votre voyage ?",
    "es":"¡Bienvenido a EgyDiscovery! ¿Cómo podemos ayudar con tu viaje?",
    "zh":"欢迎来到EgyDiscovery！我们如何为您的旅行提供帮助？"
  },
  "review_request":{
    "en":"How was your trip? We'd love your review on TripAdvisor: {link}",
    "ar":"كيف كانت رحلتك؟ نرحّب بتقييمك على تريب أدفايزر: {link}",
    "ru":"Как прошла поездка? Оставьте отзыв на TripAdvisor: {link}",
    "de":"Wie war Ihre Reise? Bewertung auf TripAdvisor: {link}",
    "it":"Com'è andato il viaggio? Recensione su TripAdvisor: {link}",
    "fr":"Comment s’est passé votre voyage ? Laissez un avis : {link}",
    "es":"¿Cómo fue tu viaje? Déjanos reseña: {link}",
    "zh":"旅途如何？欢迎在TripAdvisor点评：{link}"
  }
}
def msg(key: str, lang: str, **kwargs)->str:
  lang = (lang or "en").split("-")[0].lower()
  return MESSAGES.get(key,{}).get(lang, MESSAGES.get(key,{}).get("en","")).format(**kwargs)
