
import os, requests
def email(to, subject, body):
    sg=os.getenv("SENDGRID_API_KEY")
    mg=os.getenv("MAILGUN_API_KEY"); dom=os.getenv("MAILGUN_DOMAIN")
    if sg:
        r=requests.post("https://api.sendgrid.com/v3/mail/send",
          headers={"Authorization": f"Bearer {sg}","Content-Type":"application/json"},
          json={"personalizations":[{"to":[{"email":to}]}],"from":{"email":"noreply@yourdomain.com"},"subject":subject,"content":[{"type":"text/plain","value":body}]})
        return {"ok": r.status_code<300, "status": r.status_code}
    if mg and dom:
        r=requests.post(f"https://api.mailgun.net/v3/{dom}/messages",
          auth=("api", mg), data={"from":"norereak@"+dom,"to":[to],"subject":subject,"text":body})
        return {"ok": r.status_code<300, "status": r.status_code}
    print("[EMAIL FAKE]", to, subject, body); return {"ok": True, "fake": True}
def sms(to, body):
    sid=os.getenv("TWILIO_ACCOUNT_SID"); token=os.getenv("TWILIO_AUTH_TOKEN"); frm=os.getenv("TWOFA_SMS_FROM","+1000000000")
    if sid and token:
        r=requests.post(f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json",
                        data={"From":frm,"To":to,"Body":body}, auth=(sid, token), timeout=12)
        return {"ok": r.status_code<300, "status": r.status_code}
    print("[SMS FAKE]", to, body); return {"ok": True, "fake": True}
