
import requests, os
def ddg(q: str)->dict:
    if os.getenv("DDG_ENABLED","true").lower()!="true": return {"error":"disabled"}
    r=requests.get("https://api.duckduckgo.com/", params={"q":q,"format":"json","no_redirect":"1","no_html":"1"}, timeout=12)
    return r.json()
