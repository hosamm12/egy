
import os, requests
def ddg(q: str)->dict:
    r=requests.get("https://api.duckduckgo.com/", params={"q":q,"format":"json","no_redirect":"1","no_html":"1"}, timeout=12)
    return r.json()

def cse(q: str)->dict:
    key=os.getenv("GOOGLE_CSE_KEY"); cx=os.getenv("GOOGLE_CSE_CX")
    if not key or not cx: return {"ok": False, "reason": "CSE not configured"}
    r=requests.get("https://www.googleapis.com/customsearch/v1", params={"key":key,"cx":cx,"q":q}, timeout=15)
    return {"ok": r.status_code<300, "data": r.json()}
