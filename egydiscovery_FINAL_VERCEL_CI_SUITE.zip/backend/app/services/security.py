
import os, time, hmac, base64, hashlib, secrets, jwt
from typing import List

JWT_SECRET = os.getenv("JWT_SECRET","change-me")
JWT_TTL = int(os.getenv("JWT_TTL","86400"))

def jwt_issue(sub: str, scope: List[str]|None=None, ttl:int|None=None) -> str:
    now = int(time.time())
    payload = {"sub": sub, "iat": now, "exp": now + int(ttl or JWT_TTL)}
    if scope: payload["scope"]=scope
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def jwt_verify(tok: str) -> dict:
    return jwt.decode(tok, JWT_SECRET, algorithms=["HS256"])
