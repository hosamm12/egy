
def lead_score(data: dict)->float:
    score = 0.0
    if data.get("destination") in {"Cairo","Hurghada","Sharm"}: score += 20
    if data.get("budget","") in {"high","premium"}: score += 30
    if data.get("travel_date"): score += 10
    if data.get("group_size",1) >= 3: score += 10
    if "phone" in data: score += 10
    return min(score, 100.0)
