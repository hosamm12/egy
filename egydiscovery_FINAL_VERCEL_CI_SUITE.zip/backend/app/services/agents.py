
import os, json, requests, difflib, base64
from tenacity import retry, wait_fixed, stop_after_attempt

def llm(prompt: str)->str:
    key=os.getenv("OPENAI_API_KEY")
    if key:
        r=requests.post("https://api.openai.com/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}","Content-Type":"application/json"},
            json={"model": os.getenv("OPENAI_MODEL","gpt-4o-mini"), "messages":[{"role":"user","content":prompt}]})
        if r.status_code<300: return r.json()["choices"][0]["message"]["content"]
    # fallback
    return "LLM unavailable. Provide OPENAI_API_KEY."

def patch_from_instructions(file_path: str, original: str, edited: str)->str:
    diff=difflib.unified_diff(original.splitlines(True), edited.splitlines(True),
                              fromfile=file_path, tofile=file_path, n=3)
    return "".join(diff)

def base64_patch(patch_text: str)->str:
    return base64.b64encode(patch_text.encode()).decode()

@retry(wait=wait_fixed(2), stop=stop_after_attempt(3))
def meta_fetch_public(url: str)->dict:
    # Placeholder for Meta Graph API calls (needs tokens). For now, no scraping here.
    return {"ok": False, "reason":"Meta access token required"}

def vk_fetch_public(query: str)->dict:
    # Placeholder for VK: requires token. No scraping here.
    return {"ok": False, "reason":"VK access token required"}
