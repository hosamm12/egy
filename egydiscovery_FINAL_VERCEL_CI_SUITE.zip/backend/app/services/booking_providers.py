
import os
def create(req: dict)->dict:
    prov=os.getenv("BOOKING_PROVIDER","stub")
    if prov=="stub":
        return {"ok": True, "provider":"stub", "booking_id":"BK-"+req.get("customer","X")}
    # TODO: real integrations for amadeus/sabre/duffel once keys are provided
    return {"ok": False, "reason":"provider keys missing"}

def confirm(booking_id: str)->dict:
    return {"ok": True, "booking_id": booking_id, "status":"confirmed"}

def cancel(booking_id: str)->dict:
    return {"ok": True, "booking_id": booking_id, "status":"canceled"}
