
from .db.core import SessionLocal, engine
from .db.init import create_all

def init_db():
    create_all()
