
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
from app.db.core import SessionLocal
from app.db.models import Lead
from app.services.score import lead_score

router = APIRouter(prefix="/lead", tags=["leads"])

class LeadIn(BaseModel):
    source: str = "manual"
    payload: dict
    email: str | None = None
    phone: str | None = None

@router.post("/create")
def create(body: LeadIn):
    score = lead_score(body.payload)
    with SessionLocal() as db:
        l = Lead(source=body.source, payload=body.payload, email=body.email, phone=body.phone, score=score)
        db.add(l); db.commit(); db.refresh(l)
        return {"ok": True, "id": l.id, "score": l.score}

@router.get("/list")
def list_leads(limit: int = 20):
    with SessionLocal() as db:
        rows = db.query(Lead).order_by(Lead.id.desc()).limit(limit).all()
        return {"ok": True, "items": [ {"id":r.id,"source":r.source,"email":r.email,"phone":r.phone,"score":r.score,"status":r.status} for r in rows ]}
