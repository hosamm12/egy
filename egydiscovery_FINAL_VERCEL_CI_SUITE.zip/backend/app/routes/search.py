
from fastapi import APIRouter
from pydantic import BaseModel
from app.services.search import ddg, cse

router = APIRouter(prefix="/search", tags=["search"])
class QueryIn(BaseModel): q: str

@router.post("/ddg")
def search_ddg(body: QueryIn): return {"ok": True, "data": ddg(body.q)}

@router.post("/cse")
def search_cse(body: QueryIn): return cse(body.q)
