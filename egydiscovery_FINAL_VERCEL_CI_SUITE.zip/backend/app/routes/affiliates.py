
from fastapi import APIRouter
import os, urllib.parse

router = APIRouter(prefix="/aff", tags=["affiliates"])

@router.get("/wego")
def wego(dest: str = "Cairo"):
    base=os.getenv("WEGO_DEEP_LINK_BASE","")
    return {"ok": True, "link": f"{base}?dest={urllib.parse.quote(dest)}" if base else ""}

@router.get("/trivago")
def trivago(city: str = "Cairo"):
    base=os.getenv("TRIVAGO_DEEP_LINK_BASE","")
    return {"ok": True, "link": f"{base}?city={urllib.parse.quote(city)}" if base else ""}

@router.get("/booking")
def booking(city: str = "Cairo"):
    base=os.getenv("BOOKING_DEEP_LINK_BASE","")
    return {"ok": True, "link": f"{base}?city={urllib.parse.quote(city)}" if base else ""}
