
from fastapi import APIRouter, HTTPException, Body
from pydantic import BaseModel
from app.services.agents import llm, patch_from_instructions, base64_patch

router = APIRouter(prefix="/agents", tags=["agents"])

class PlanIn(BaseModel):
    agent: str
    goal: str
    context: dict | None = None

@router.post("/plan")
def plan(body: PlanIn):
    prompt = f"You are {body.agent}. Goal: {body.goal}. Context: {body.context or {}}. Produce a concise plan."
    return {"ok": True, "plan": llm(prompt)}

class PatchIn(BaseModel):
    file_path: str
    original: str
    edited: str

@router.post("/developer/patch")
def developer_patch(body: PatchIn):
    diff = patch_from_instructions(body.file_path, body.original, body.edited)
    return {"ok": True, "patch": diff, "base64": base64_patch(diff)}
