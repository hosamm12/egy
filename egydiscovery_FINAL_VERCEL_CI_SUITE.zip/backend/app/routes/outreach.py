
from fastapi import APIRouter
from pydantic import BaseModel
from app.services.notify import email, sms
router = APIRouter(prefix="/outreach", tags=["outreach"])

class EmailIn(BaseModel):
    to: str; subject: str; body: str
@router.post("/email")
def send_email(body: EmailIn):
    return email(body.to, body.subject, body.body)

class SmsIn(BaseModel):
    to: str; body: str
@router.post("/sms")
def send_sms(body: SmsIn):
    return sms(body.to, body.body)
