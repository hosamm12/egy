
from fastapi import APIRouter
from pydantic import BaseModel
from app.services.enrich import ddg
router = APIRouter(prefix="/enrich", tags=["enrich"])
class EnrichIn(BaseModel): q: str
@router.post("/ddg")
def enrich_ddg(body: EnrichIn):
    return {"ok": True, "data": ddg(body.q)}
