
from fastapi import APIRouter
from pydantic import BaseModel
from datetime import datetime, timedelta
import os
from app.scheduler import schedule_followup
from app.templates.messages import msg

router = APIRouter(prefix="/followup", tags=["followup"])

class FollowIn(BaseModel):
    channel: str = "email"
    to: str
    lang: str = "en"
    after_hours: int = 24
    template: str = "review_request"

@router.post("/schedule")
def follow_schedule(body: FollowIn):
    link = os.getenv("TRIPADVISOR_REVIEW_URL","https://tripadvisor.com/")
    subject = "Thanks for your trip"
    text = msg(body.template, body.lang, link=link)
    run_at = datetime.utcnow() + timedelta(hours=body.after_hours)
    schedule_followup("review", body.channel, body.to, subject, text, run_at)
    return {"ok": True, "run_at": run_at.isoformat()+"Z"}
