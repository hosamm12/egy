
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse
from authlib.integrations.starlette_client import OAuth
import os, time, jwt, pyotp
from app.services.notify import email, sms

router = APIRouter(prefix="/auth", tags=["auth"])

def _jwt(payload): return jwt.encode(payload, os.getenv("JWT_SECRET","change-me"), algorithm="HS256")

def _oauth_google():
    oauth=OAuth()
    cid=os.getenv("GOOGLE_CLIENT_ID"); cs=os.getenv("GOOGLE_CLIENT_SECRET")
    if cid and cs:
        oauth.register(name="google", client_id=cid, client_secret=cs,
                       server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
                       client_kwargs={"scope":"openid email profile"})
    return oauth

@router.get("/google/login")
async def google_login(request: Request):
    oauth=_oauth_google()
    if "google" not in oauth._clients: raise HTTPException(400,"Google not configured")
    redirect=os.getenv("PUBLIC_BASE_URL","http://localhost")+os.getenv("GOOGLE_REDIRECT_PATH","/auth/google/callback")
    return await oauth.google.authorize_redirect(request, redirect)

@router.get("/google/callback")
async def google_callback(request: Request):
    oauth=_oauth_google(); tok=await oauth.google.authorize_access_token(request)
    userinfo=tok.get("userinfo") or {}; sub=userinfo.get("sub") or userinfo.get("email")
    if not sub: raise HTTPException(400,"No userinfo")
    # send 2FA code by email
    code=pyotp.random_base32()[:6]
    request.session["pending_user"]=sub
    request.session["otp_code"]=code
    email(userinfo.get("email","unknown@example.com"), "Your code", f"Code: {code}")
    return RedirectResponse(url="/auth/2fa/pending")

@router.get("/2fa/pending")
async def twofa_pending():
    return {"ok": True, "message":"Code sent. POST /auth/2fa/verify {code}"}

@router.post("/2fa/verify")
async def twofa_verify(request: Request):
    data=await request.json()
    code=str(data.get("code","")).strip()
    user=request.session.get("pending_user")
    if not user: raise HTTPException(400,"No pending user")
    if code and code == request.session.get("otp_code"):
        t=int(time.time()); token=_jwt({"sub":user,"iat":t,"exp":t+86400,"scope":["user"]})
        request.session.pop("pending_user",None); request.session.pop("otp_code",None)
        return {"ok": True, "token": token}
    raise HTTPException(400,"Invalid code")
