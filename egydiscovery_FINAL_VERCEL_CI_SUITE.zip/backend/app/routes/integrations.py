
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel
import os

router = APIRouter(prefix="/integrations", tags=["integrations"])

class TAIn(BaseModel):
    booking_id: str
    email: str | None = None
    phone: str | None = None
    meta: dict | None = None

@router.post("/tripadvisor/webhook")
def tripadvisor_webhook(body: TAIn, x_token: str = Header(default="")):
    if x_token != os.getenv("TRIPADVISOR_WEBHOOK_TOKEN",""):
        raise HTTPException(401, "Invalid token")
    # TODO: persist lead, trigger review email with TRIPADVISOR_REVIEW_URL
    return {"ok": True, "action": "recorded_lead_and_planned_review"}

@router.get("/review/link")
def review_link():
    return {"ok": True, "link": os.getenv("TRIPADVISOR_REVIEW_URL","")}
