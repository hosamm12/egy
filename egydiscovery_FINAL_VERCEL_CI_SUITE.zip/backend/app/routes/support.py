
from fastapi import APIRouter
from pydantic import BaseModel
from app.services.notify import email, sms

router = APIRouter(prefix="/support", tags=["support"])

class TicketIn(BaseModel):
    channel: str = "email"  # email|sms
    to: str
    subject: str
    body: str

@router.post("/ticket")
def support_ticket(body: TicketIn):
    if body.channel=="sms":
        return sms(body.to, body.body)
    return email(body.to, body.subject, body.body)
