
from fastapi import APIRouter
from pydantic import BaseModel
from app.services.booking_providers import create, confirm, cancel

router = APIRouter(prefix="/booking", tags=["booking"])

class BookingIn(BaseModel):
    customer: str
    destination: str
    dates: dict
    extras: dict | None = None

@router.post("/create")
def booking_create(body: BookingIn):
    return create(body.model_dump())

@router.post("/confirm/{booking_id}")
def booking_confirm(booking_id: str):
    return confirm(booking_id)

@router.post("/cancel/{booking_id}")
def booking_cancel(booking_id: str):
    return cancel(booking_id)
