
from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel
from app.services.security import jwt_issue, jwt_verify
import os

router = APIRouter(prefix="/auth", tags=["auth"])

class IssueIn(BaseModel):
    subject: str
    scope: list[str] = []
    ttl: int | None = None

@router.post("/bootstrap")
def bootstrap(x_bootstrap: str = Header(default="")):
    if x_bootstrap != os.getenv("ADMIN_BOOTSTRAP_TOKEN",""):
        raise HTTPException(401, "Invalid bootstrap")
    return {"ok": True, "token": jwt_issue("admin", ["admin"])}

@router.post("/issue")
def issue(body: IssueIn, authorization: str | None = Header(default=None)):
    if not authorization or "admin" not in (jwt_verify(authorization.split(" ",1)[1]).get("scope",[])):
        raise HTTPException(403, "admin required")
    return {"ok": True, "token": jwt_issue(body.subject, body.scope, body.ttl)}

@router.get("/verify")
def verify(authorization: str | None = Header(default=None)):
    if not authorization: return {"ok": False}
    try: return {"ok": True, "payload": jwt_verify(authorization.split(" ",1)[1])}
    except Exception: return {"ok": False}
