
import os, atexit
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.date import DateTrigger
from app.services.notify import email, sms

scheduler = BackgroundScheduler()
scheduler.start()
atexit.register(lambda: scheduler.shutdown(wait=False))

def schedule_followup(dest: str, channel: str, to: str, subject: str, body: str, run_at):
    def job():
        if channel == "sms":
            sms(to, body)
        else:
            email(to, subject, body)
    scheduler.add_job(job, DateTrigger(run_date=run_at), id=f"followup:{dest}:{to}", replace_existing=True)
