
from .init import create_all
if __name__ == "__main__":
    create_all(); print("DB tables created.")
