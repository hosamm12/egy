
from .core import Base, engine
from . import models
def create_all():
    Base.metadata.create_all(bind=engine)
