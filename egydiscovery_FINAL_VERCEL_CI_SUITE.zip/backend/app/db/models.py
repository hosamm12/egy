
from sqlalchemy import Column, Integer, String, JSON, DateTime, Float
from sqlalchemy.sql import func
from .core import Base

class Lead(Base):
    __tablename__ = "leads"
    id = Column(Integer, primary_key=True, index=True)
    source = Column(String, index=True)
    payload = Column(JSON)
    email = Column(String, index=True)
    phone = Column(String, index=True)
    score = Column(Float, default=0.0)
    status = Column(String, default="new")
    created_at = Column(DateTime, server_default=func.now())

class AgentMemory(Base):
    __tablename__ = "agent_memory"
    id = Column(Integer, primary_key=True)
    agent = Column(String, index=True)
    key = Column(String, index=True)
    value = Column(JSON)
    created_at = Column(DateTime, server_default=func.now())
