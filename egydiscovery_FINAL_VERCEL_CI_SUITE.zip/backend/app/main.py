
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from app.routes import auth, leads, agents, integrations, outreach, enrich, health, affiliates, search, followup, support, booking, auth_sso
from app.db import init_db

app = FastAPI(title="Egydiscovery Agent Suite", version="1.0")
app.add_middleware(SessionMiddleware, secret_key=os.getenv('JWT_SECRET','change-me'))

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in os.getenv("CORS_ORIGINS","*").split(",") if o.strip()] or ["*"],
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)

# Routers
app.include_router(health.router)
app.include_router(auth.router)
app.include_router(leads.router)
app.include_router(enrich.router)
app.include_router(outreach.router)
app.include_router(integrations.router)
app.include_router(agents.router)

@app.on_event("startup")
async def on_start():
    init_db()

app.include_router(affiliates.router)
