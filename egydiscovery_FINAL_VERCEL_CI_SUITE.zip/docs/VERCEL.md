
# Vercel Deployment (Frontend)

## GitHub Action
We included `.github/workflows/vercel.yml`. Add these repository **Secrets**:
- `VERCEL_TOKEN`
- `VERCEL_ORG_ID`
- `VERCEL_PROJECT_ID`
- `NEXT_PUBLIC_API_URL` (e.g., your API URL on VPS)

Push to **main** → deploys to Vercel production. PRs → preview deployments.

## Manual (local)
```
cd frontend
npm ci
NEXT_PUBLIC_API_URL=http://localhost:8000 npm run build
vercel --prod  # if you have Vercel CLI configured
```
