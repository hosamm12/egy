
# Email Deliverability (DKIM/SPF/DMARC)
1) Set SPF: `v=spf1 include:sendgrid.net include:mailgun.org ~all`
2) DKIM: create DNS TXT as your provider instructs (SendGrid/Mailgun panel).
3) DMARC: `v=DMARC1; p=quarantine; rua=mailto:dmarc@yourdomain.com`
