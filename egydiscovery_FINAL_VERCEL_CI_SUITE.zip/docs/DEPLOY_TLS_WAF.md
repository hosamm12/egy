
# HTTPS + WAF
- Use `infra/waf/docker-compose.waf.yml` with image `owasp/modsecurity-crs:nginx`.
- Mount `/etc/letsencrypt` with your certs or issue via certbot on the host.
- Point DNS A record to your VPS; then run the compose.
