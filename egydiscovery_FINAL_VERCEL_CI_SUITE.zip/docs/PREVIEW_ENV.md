
# PR Preview Environments
- Configure wildcard DNS (or manual Nginx map) for `*.preview.yourdomain.com`.
- Set repo secrets: `SSH_HOST`, `SSH_USER`, `SSH_KEY`, `PROJECT_DIR`, and env `PREVIEW_BASE_DOMAIN`.
- The workflow fetches PR head to `pr-<num>` branch and rebuilds containers on your server.
