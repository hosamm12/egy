
#!/usr/bin/env python3
from pathlib import Path
from dotenv import dotenv_values
ROOT = Path(__file__).resolve().parents[1]
vals = dotenv_values(ROOT/"config/master.env")
def write_env(path):
    lines=[f"{k}={v}" for k,v in vals.items() if v is not None]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines)+"\n", encoding="utf-8")
    print("wrote", path)
write_env(ROOT/"backend/.env")
write_env(ROOT/"frontend/.env.local")
