
#!/usr/bin/env bash
set -euo pipefail
python3 scripts/sync_env.py || true
docker compose up -d --build
# Optional WAF stack:
# docker compose -f infra/waf/docker-compose.waf.yml up -d --build
