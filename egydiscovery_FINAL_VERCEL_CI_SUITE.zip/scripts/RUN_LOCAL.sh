
#!/usr/bin/env bash
set -euo pipefail
python3 scripts/sync_env.py || true
docker compose up -d --build
echo "FE: http://localhost"
echo "API: http://localhost:8000"
echo "n8n: http://localhost:5678  (admin/admin)"
