module.exports = { reactStrictMode: true };
module.exports.i18n = { locales: ['en','ar','de','it','fr','es','ru','zh'], defaultLocale: 'en' };
