
export default function Flow(){
  return <main style={{padding:20,lineHeight:1.8}}>
    <h2>Support → Booking → Follow-up</h2>
    <ol>
      <li>Support agent receives inquiry (email/WhatsApp/SMS)</li>
      <li>Lead created → Enrichment (DDG/CSE) → Scoring</li>
      <li>Booking agent creates/confirm/cancel via provider</li>
      <li>Follow-up agent schedules TripAdvisor review request</li>
      <li>Analytics & affiliates (Wego/Trivago/Booking)</li>
    </ol>
  </main>
}
