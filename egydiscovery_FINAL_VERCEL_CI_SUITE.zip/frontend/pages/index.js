
import axios from 'axios'
export default function Home(){
  const test = async ()=>{
    const r = await axios.get(process.env.NEXT_PUBLIC_API_URL + '/healthz')
    alert(JSON.stringify(r.data))
  }
  return <main style={{padding:20}}>
    <h1>Egydiscovery Agent Suite</h1>
    <p>API: {process.env.NEXT_PUBLIC_API_URL}</p>
    <button onClick={test}>Health Check</button>
    <ul>
      <li><a href="/leads">Leads</a></li>
      <li><a href="/agents">Agents</a></li>
    </ul>
  </main>
}
