
import {useEffect, useState} from 'react'
import axios from 'axios'
export default function Leads(){
  const [items,setItems]=useState([])
  useEffect(()=>{ axios.get(process.env.NEXT_PUBLIC_API_URL+'/lead/list').then(r=>setItems(r.data.items||[])) },[])
  return <main style={{padding:20}}>
    <h2>Leads</h2>
    <pre>{JSON.stringify(items,null,2)}</pre>
  </main>
}
