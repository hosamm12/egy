
import { useState } from 'react'
export default function Dev(){
  const [key,setKey]=useState('')
  const [output,setOutput]=useState('')
  const api=process.env.NEXT_PUBLIC_API_URL
  const call = async (path, body) => {
    const r = await fetch(api+path, {method:'POST', headers:{'Content-Type':'application/json','X-Dev-Key':key}, body: JSON.stringify(body||{})})
    setOutput(await r.text())
  }
  return <main style={{padding:20}}>
    <h2>Developer Sandbox</h2>
    <input placeholder="X-Dev-Key" value={key} onChange={e=>setKey(e.target.value)} style={{padding:8}}/>
    <div style={{display:'grid', gap:10, maxWidth:600, marginTop:20}}>
      <button onClick={()=>call('/agents/plan',{agent:'developer',goal:'run tests'})}>Plan</button>
      <button onClick={()=>call('/agents/developer/patch',{file_path:'README.md',original:'old',edited:'new'})}>Generate Patch</button>
    </div>
    <pre style={{marginTop:20,background:'#111',color:'#0f0',padding:12,whiteSpace:'pre-wrap'}}>{output}</pre>
  </main>
}
