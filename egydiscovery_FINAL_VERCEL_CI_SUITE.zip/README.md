
# Egydiscovery Agent Suite — Full Stack (Backend + Frontend + n8n + CI/CD)

## Run (Dev, on your laptop)
```bash
python3 scripts/sync_env.py               # copies config/master.env -> backend/.env and frontend/.env.local
docker compose up -d --build              # db + api + frontend + n8n + nginx
# FE: http://localhost/  | API: http://localhost:8000 | n8n: http://localhost:5678 (admin/admin)
```

## VPS (One script)
```bash
bash scripts/vps_bootstrap.sh             # docker + firewall + fail2ban
# clone repo into /opt/egydiscovery
python3 scripts/sync_env.py
docker compose up -d --build
```

## First admin token
```
curl -X POST http://localhost:8000/auth/bootstrap -H "X-Bootstrap: $ADMIN_BOOTSTRAP_TOKEN"
```

## n8n flows
- `n8n/lead_enrich_score.json` : HTTP In → Enrich (DDG) → Create Lead (score) → Email Notify → HTTP Out

## Developer Agent (patch generator)
- POST `/agents/developer/patch` with `{file_path, original, edited}` returns a unified diff + base64.  
- Paste into a GitHub comment between:
```
---BEGIN GPT PATCH---
```base64
...base64...
```
---END GPT PATCH---
```
GitHub Action `patch-intake.yml` opens a PR automatically.

## Notes & Compliance
- TripAdvisor/Meta/VK integrations are **stubs** pending your API keys and compliance with their terms.
  - No scraping is implemented; provide API credentials or email/webhook sources.
- OpenAI LLM optional; if missing, system still runs (enrichment via DDG).
- Extend scoring rules in `backend/app/services/score.py`.
